# DroneVision YOLO Dataset

Annotated: 5/6/2026
Annotated images: 117
Classes (7): person, car, tree, building, road, drone, spiderman_figure

## Format
Each label file contains one row per bounding box:
  class_id  cx  cy  width  height
All values normalized 0-1 relative to image dimensions.

## Usage
Upload to Roboflow for train/val split and augmentation,
or use directly with YOLOv8/ultralytics:

  from ultralytics import YOLO
  model = YOLO('yolov8n.pt')
  model.train(data='data.yaml', epochs=50)
